to zip_processor import ZipProcessor

file = ZipProcessor('')
file.process_zip()